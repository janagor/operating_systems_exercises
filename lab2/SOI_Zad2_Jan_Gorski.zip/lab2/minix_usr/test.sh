cc test.c
./a.out
rm a.out
